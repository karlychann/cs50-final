# personal touch: require users to have at least 3 numbers and 1 letter in password

import os
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required
# Configure application
app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///users.db")
#does this automatically make a database later or does it add to the existing finance database that is uploaded in the zip file?

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/")
@login_required
def home():
    return render_template("home.html")

@app.route("/practice", methods=["GET"])
@login_required
def practice():
    return render_template("practice.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")

#why can we not just do an href lib.html isntead of this?
@app.route("/lib")
def lib():
    return render_template("lib.html")

@app.route("/canthelp")
def canthelp():
    return render_template("canthelp.html")

@app.route("/edelweiss")
def edelweiss():
    return render_template("edelweiss.html")

@app.route("/heyjude")
def heyjude():
    return render_template("heyjude.html")

@app.route("/hello")
def hello():
    return render_template("hello.html")

@app.route("/londonbridge")
def londonbridge():
    return render_template("londonbridge.html")

@app.route("/marylamb")
def marylamb():
    return render_template("marylamb.html")

@app.route("/aboutus")
def aboutus():
    return render_template("aboutus.html")

@app.route("/userinput")
def userinput():
    return render_template("userinput.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

        # check whether username is inputted
        if not username:
            return apology("Missing username")
        # check whether password is inputted
        elif not password:
            return apology("Missing password")
        # check whether confirmation is inputted
        elif not confirmation:
            return apology("Missing confirmation password")
        # check whether password and confirmation match
        elif password != confirmation:
            return apology("Password and confirmation password don't match")

        # ensure that the password contains at least 3 letters and 1 number
        alphaCount = 0
        numCount = 0
        for character in password:
            if character.isalpha():
                alphaCount += 1
            if character.isdigit():
                numCount += 1
        if (alphaCount < 3):
            return apology("Password must contain at least 3 letters")
        elif (numCount < 1):
            return apology("Password must contain at least 1 number")

        try:
            # id will contain something after this has successfully been executed
            id = db.execute("INSERT INTO users (username, hash) VALUES(?, ?)", username, generate_password_hash(password))

        except ValueError:
            # if username is not able to be inputted, it already exists so render an apology
            return apology("Username is taken")

        # remember which user is registered
        session["user_id"] = id

        flash("You are registered!")
        # Automatically user to library
        return redirect("/lib")

    else:
        return render_template("register.html")