Overview:

Our website, Pitch Perfect, allows singers/musicians to practice a curated selection of songs, upload their own music, or practice their sight-reading skills! Often when learning new music, singers read the notes on their sheet music but cannot tell if they are singing these notes in tune. Singers often make use of muscle memory, and therefore it can be dangerous to practice wrong notes over and over again.

We are providing a useful tool that checks if musicians are in tune via live and practically instantaneous feedback. If the correct note is sung/played, musicians are encouraged, and if they make a mistake, they are able to retry until they sing or play the correct note.
Using Pitch Perfect, singers (and other musicians) can drill their pitch so that they practice (and later perform) correctly!

Accessing the website:

To access the website, download the zip file and upload into VSCode.
Unzip the project.zip file using the command “unzip project.zip”.
The website is on a flask server, so “cd” into the finalproject directory, export an API key “export API_KEY=(value)”, and then run the command “flask run” to access the development server.

Using the website:

The url will bring you to the Pitch Perfect homepage, which contains a brief explanation of the project. In order to access the built-in music library, you must log in or register. Once you have registered or logged in and accessed your account, you will be subsequently redirected to the music library page (or you can access this page from the button in the navigation bar).

The music library has various songs sorted into different categories based on sight-reading difficulty level. Each level displays the sheet music of the songs, as well as a link to each practice page.

To access the practice page of a particular song, click on the green button below the sheet music.

On each song’s practice page, you can view a selected excerpt of sheet music, a button to play the starting note of the excerpt, and a START button to run the pitch-checking program.
Once START is pressed, as you sing or play each note, the program will alert you if the notes you are singing or playing are correct.
If a note is not correct, the program stops and tells you what note you sang (incorrectly), and what the correct note was supposed to be.
At any point after START-ing a song’s practice program, users can click the RESTART button to reset the program and try again from the beginning (first note).
If you successfully sing all of the notes correctly, completing the practice excerpt with no mistakes detected, a celebratory message appears!

The music library also contains a practice your own song feature. At the bottom of the music library page there is a bonus “Make Your Own” section, linking to a page that allows users to upload their own song(s) and personalize the music that they are practicing!
Once you have clicked the “make your own” button, you will be redirected to a customizable practice page.
On this page, you can upload your own sheet music image and manually input the notes of the music (notes must be inputted one at a time).
IMPORTANT NOTES: as stated on the Make Your Own page, notes must be inputted one at a time. Additionally, the program only takes the notes C, C#, D, D#, E, F, F#, G, G#, A, A#, and B. In other words, the notes E♭or B#, for example, would not be recognized. You must convert any notes with flats to their sharp counterparts.
The starting note on this page is not applicable but can be manually coded for each user to upload a .wav file in the future.

Once you have inputted your sequence of notes the START button will appear, and the program can check to see if you are singing your notes correctly!

Lastly, the navigation bar contains an extra “About Us” page that provides a bit of background about us (the Creators) and our project!

Our brief walk-through youtube video: https://youtu.be/JbOrb1OT-Vw
